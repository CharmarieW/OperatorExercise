import UIKit

// Variables
var a = 1
var b = 21
var c = 13
var d = 7

// Operations
let add = a + c
let sub = c - d
let mul = d * a
let div = b / c

// Print
print("a + c = \(add)")
print("c - d = \(sub)")
print("d * a = \(mul)")
print("b / c = \(div)")
